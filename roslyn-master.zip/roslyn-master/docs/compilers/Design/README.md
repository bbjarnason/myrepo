Design Docs
===========

This directory is a place for design documents for the Roslyn compilers.
