COM interop
===========

[This is a placeholder. We need some more documentation here]

We have a number of features in the compiler/language to support COM interop, none of which is described in the language specification.
