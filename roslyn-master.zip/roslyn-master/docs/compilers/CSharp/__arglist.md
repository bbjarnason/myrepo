__arglist
=========

[This is a placeholder. We need some more documentation here]

What is the __arglist language extension, exactly?
AFAIK it's an undocumented C# feature that mimics C++'s varargs and is present to support interop with managed C and C++..

See also [http://bartdesmet.net/blogs/bart/archive/2006/09/28/4473.aspx](http://bartdesmet.net/blogs/bart/archive/2006/09/28/4473.aspx)
