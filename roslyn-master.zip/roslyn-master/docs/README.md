README
======

This file is a placeholder.  This directory will contain public documentation.
