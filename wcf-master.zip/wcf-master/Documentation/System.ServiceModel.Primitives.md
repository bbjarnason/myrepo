This library contains the foundation types used by all the other WCF libraries.

[Open issues for this library](https://github.com/dotnet/wcf/issues?q=is%3Aopen+is%3Aissue+label%3ASystem.ServiceModel.Primitives)

[Not yet supported in this library](https://github.com/dotnet/wcf/issues?q=is%3Aopen+is%3Aissue+label%3A%22not+yet+supported%22+label%3ASystem.ServiceModel.Primitives)



