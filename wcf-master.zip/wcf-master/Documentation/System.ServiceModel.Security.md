This library contains the types used for additional security for WCF communication.

[Open issues for this library](https://github.com/dotnet/wcf/issues?q=is%3Aopen+is%3Aissue+label%3ASystem.ServiceModel.Security)

[Not yet supported in this library](https://github.com/dotnet/wcf/issues?q=is%3Aopen+is%3Aissue+label%3A%22not+yet+supported%22+label%3ASystem.ServiceModel.Security)
