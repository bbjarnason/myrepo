This library contains the types used by the NetTcpBinding to support TCP. This page can be used to browse the current status of these types. 

[Open issues for this library](https://github.com/dotnet/wcf/issues?q=is%3Aopen+is%3Aissue+label%3ASystem.ServiceModel.NetTcp)

[Not yet supported in this library](https://github.com/dotnet/wcf/issues?q=is%3Aopen+is%3Aissue+label%3A%22not+yet+supported%22+label%3ASystem.ServiceModel.NetTcp)

#### NetTcpBinding ####
----------------
[Open issues](https://github.com/dotnet/wcf/issues?q=is%3Aopen+is%3Aissue+label%3ASystem.ServiceModel.NetTcp+NetTcpBinding+in%3Atitle)

[Not yet supported](https://github.com/dotnet/wcf/issues?q=is%3Aopen+is%3Aissue+label%3A%22not+yet+supported%22+label%3ASystem.ServiceModel.NetTcp+NetTcpBinding+in%3Atitle)