This library contains the types used to communicate with WCF using Http. 

[Open issues for this library](https://github.com/dotnet/wcf/issues?q=is%3Aopen+is%3Aissue+label%3ASystem.ServiceModel.Http)

[Not yet supported in this library](https://github.com/dotnet/wcf/issues?q=is%3Aopen+is%3Aissue+label%3A%22not+yet+supported%22+label%3ASystem.ServiceModel.Http)

#### BasicHttpBinding ####
----------------
[Open issues](https://github.com/dotnet/wcf/issues?q=is%3Aopen+is%3Aissue+label%3ASystem.ServiceModel.Http+BasicHttpBinding+in%3Atitle)

[Not yet supported](https://github.com/dotnet/wcf/issues?q=is%3Aopen+is%3Aissue+label%3A%22not+yet+supported%22+label%3ASystem.ServiceModel.Http+BasicHttpBinding+in%3Atitle)

#### NetHttpBinding ####
----------------
[Open issues](https://github.com/dotnet/wcf/issues?q=is%3Aopen+is%3Aissue+label%3ASystem.ServiceModel.Http+NetHttpBinding+in%3Atitle)

[Not yet supported](https://github.com/dotnet/wcf/issues?q=is%3Aopen+is%3Aissue+label%3A%22not+yet+supported%22+label%3ASystem.ServiceModel.Http+NetHttpBinding+in%3Atitle)