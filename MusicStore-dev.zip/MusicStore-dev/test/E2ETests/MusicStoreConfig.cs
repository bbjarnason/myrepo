﻿namespace E2ETests
{
    public class MusicStoreConfig
    {
        public const string ConnectionStringKey = "Data__DefaultConnection__ConnectionString";
    }
}
